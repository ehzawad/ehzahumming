# ehzahumming

A simple utility to generate "humming" sounds.
