from ehzahumming import generate_hum

def test_generate_hum():
    assert generate_hum(5) == "hmmmmhmmmmhmmmmhmmmmhmmmm"
