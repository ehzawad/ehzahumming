from .humming import generate_hum
