def generate_hum(duration):
    # a simple function that pretends to generate a humming sound
    return "hmmmm" * duration
